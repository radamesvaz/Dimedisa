export default {
    token: 'U2e6_ZgnB_E7N9_baV8',
    companyId: '5352707'
}